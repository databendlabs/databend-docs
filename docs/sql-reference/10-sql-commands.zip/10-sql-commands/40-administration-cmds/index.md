---
title: Administration Commands
---
import IndexOverviewList from '@site/src/components/IndexOverviewList';

This page provides reference information for the system administration commands in Databend.

<IndexOverviewList />