---
title: DROP STAGE
sidebar_position: 7
---

Removes a stage.

## Syntax

```sql
DROP STAGE [ IF EXISTS ] <stage_name>;
```

## Examples

```sql
DROP STAGE IF EXISTS test_stage;
```