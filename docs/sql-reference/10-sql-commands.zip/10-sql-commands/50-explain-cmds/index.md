---
title: Explain Commands
---
import IndexOverviewList from '@site/src/components/IndexOverviewList';

This page provides reference information for the explain-related commands in Databend.

<IndexOverviewList />